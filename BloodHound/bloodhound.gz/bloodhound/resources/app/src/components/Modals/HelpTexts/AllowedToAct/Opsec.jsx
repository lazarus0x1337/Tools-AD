import React from 'react';

const Opsec = () => {
    return (
        <p>
            To execute this attack, the Rubeus C# assembly needs to be executed
            on some system with the ability to send/receive traffic in the
            domain.
        </p>
    );
};

export default Opsec;
