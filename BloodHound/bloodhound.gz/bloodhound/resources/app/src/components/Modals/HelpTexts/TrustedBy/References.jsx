import React from 'react';

const References = () => {
    return <></>;
};

export default References;
