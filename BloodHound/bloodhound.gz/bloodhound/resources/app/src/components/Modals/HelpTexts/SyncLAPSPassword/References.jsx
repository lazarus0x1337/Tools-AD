import React from 'react';


const References = () => {
    return(
        <>
            <a href="https://github.com/simondotsh/DirSync">https://github.com/simondotsh/DirSync</a>
            <br />
            <a href="https://simondotsh.com/infosec/2022/07/11/dirsync.html">https://simondotsh.com/infosec/2022/07/11/dirsync.html</a>
        </>
    )
};

export default References;
