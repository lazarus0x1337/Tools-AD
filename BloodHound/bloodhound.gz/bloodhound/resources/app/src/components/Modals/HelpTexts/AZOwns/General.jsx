import React from 'react';

const General = () => {
    return (
        <p>
            Object ownership means almost all abuses are possible against the
            target object.
        </p>
    );
};

export default General;
