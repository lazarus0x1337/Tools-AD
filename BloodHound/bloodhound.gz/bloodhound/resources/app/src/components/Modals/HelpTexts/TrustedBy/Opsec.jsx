import React from 'react';

const Opsec = () => {
    return <p>There is no opsec associated with this edge</p>;
};

export default Opsec;
