import React from 'react';

const Abuse = () => {
    return <p>There is no abuse info related to this edge.</p>;
};

export default Abuse;
