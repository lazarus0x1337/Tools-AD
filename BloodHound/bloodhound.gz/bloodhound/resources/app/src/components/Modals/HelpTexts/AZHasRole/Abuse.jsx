import React from 'react';

const Abuse = () => {
    return (
        <>
            <p>
                No abuse is necessary. This edge only indicates
                that the principal has been granted a particular
                AzureAD admin role.
            </p>
        </>
    );
};

export default Abuse;
