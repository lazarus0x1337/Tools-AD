import React from 'react';

const Abuse = () => {
    return (
        <p>
            Create a new credential for the app, then authenticate to the tenant
            as the app's service principal, then abuse whatever privilege it is
            that the service principal has.
        </p>
    );
};

export default Abuse;
