import React from 'react';

const Opsec = () => {
    return (
        <p>
            This depends on the target object and how to take advantage of this
            privilege. Opsec considerations for each abuse primitive are
            documented on the specific abuse edges and on the BloodHound wiki.
        </p>
    );
};

export default Opsec;
