import React from 'react';

const General = () => {
    return <p>The ability to read certificates from key vaults</p>;
};

export default General;
