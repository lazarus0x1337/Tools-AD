import React from 'react';

const General = () => {
    return (
        <p>
            The Azure App runs as the Service Principal when it needs to
            authenticate to the tenant
        </p>
    );
};

export default General;
