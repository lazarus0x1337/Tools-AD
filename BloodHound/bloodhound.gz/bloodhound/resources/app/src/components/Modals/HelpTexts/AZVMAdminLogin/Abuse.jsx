import React from 'react';

const Abuse = () => {
    return (
        <>
            <p>
                Connect to the VM via RDP and you will be granted local admin rights
                on the VM.
            </p>
        </>
    );
};

export default Abuse;
