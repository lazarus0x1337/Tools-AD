import React from 'react';

const References = () => {
    rerturn(
        <>
            <a href='https://wald0.com/?p=179'>https://wald0.com/?p=179</a>
            <br />
            <a href='https://blog.cptjesus.com/posts/bloodhound15'>
                https://blog.cptjesus.com/posts/bloodhound15
            </a>
        </>
    );
};

export default References;
