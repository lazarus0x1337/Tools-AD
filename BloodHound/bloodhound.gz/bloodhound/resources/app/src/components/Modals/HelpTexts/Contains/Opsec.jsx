import React from 'react';

const Opsec = () => {
    return <p>There are no opsec considerations related to this edge.</p>;
};

export default Opsec;
