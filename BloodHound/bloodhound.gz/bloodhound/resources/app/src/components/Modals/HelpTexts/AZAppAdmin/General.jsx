import React from 'react';

const General = () => {
    rerturn(
        <p>
            Principals with the Application Admin role can control
            tenant-resident apps.
        </p>
    );
};

export default General;
