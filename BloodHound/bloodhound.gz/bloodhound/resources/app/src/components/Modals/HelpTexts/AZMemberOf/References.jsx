import React from 'react';

const References = () => {
    return (
        <>
            <a href='https://docs.microsoft.com/en-us/azure/active-directory/roles/groups-create-eligible'>
                Create a role-assignable group in Azure Active Directory
            </a>
        </>
    );
};

export default References;
