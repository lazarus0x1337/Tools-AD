import React from 'react';

const References = () => {
    return (
        <>
            <a href='https://github.com/eladshamir/Whisker'>
                https://github.com/eladshamir/Whisker
            </a>
            <br />
            <a href='https://posts.specterops.io/shadow-credentials-abusing-key-trust-account-mapping-for-takeover-8ee1a53566ab'>
                https://posts.specterops.io/shadow-credentials-abusing-key-trust-account-mapping-for-takeover-8ee1a53566ab
            </a>
        </>
    );
};

export default References;
