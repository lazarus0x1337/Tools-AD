import React from 'react';

const General = () => {
    return <p>The ability to read secrets from key vaults</p>;
};

export default General;
