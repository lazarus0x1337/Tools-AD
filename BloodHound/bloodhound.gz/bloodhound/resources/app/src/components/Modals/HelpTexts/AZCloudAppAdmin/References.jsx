import React from 'react';

const References = () => {
    return (
        <p>
            <a href='https://dirkjanm.io/azure-ad-privilege-escalation-application-admin/'>
                https://dirkjanm.io/azure-ad-privilege-escalation-application-admin/
            </a>
        </p>
    );
};

export default References;
