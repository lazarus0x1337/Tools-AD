import React from 'react';

const Opsec = () => {
    return (
        <p>
            This depends on what you do, see other edges as far as opsec
            considerations for activating roles
        </p>
    );
};

export default Opsec;
