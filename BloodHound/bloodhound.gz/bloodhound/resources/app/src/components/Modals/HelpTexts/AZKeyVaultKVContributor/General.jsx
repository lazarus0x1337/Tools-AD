import React from 'react';

const General = () => {
    return (
        <p>
            The Key Vault Contributor role grants full control of the 
            target Key Vault. This includes the ability to read all secrets 
            stored on the Key Vault.
        </p>
    );
};

export default General;
