import React from 'react';

const General = () => {
    return (
        <p>
            The contributor role grants almost all abusable privileges in all
            circumstances, with some exceptions. Those exceptions are not
            collected by AzureHound.
        </p>
    );
};

export default General;
