import React from 'react';

const General = () => {
    return (
        <p>
            The Azure Automation Contributor role grants full control
            of the target Azure Automation Account. This includes 
            the ability to execute arbitrary commands on the Automation 
            Account.
        </p>
    );
};

export default General;
