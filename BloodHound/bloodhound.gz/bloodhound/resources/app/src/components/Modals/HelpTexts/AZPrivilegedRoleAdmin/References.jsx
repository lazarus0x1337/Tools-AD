import React from 'react';

const References = () => {
    return (
        <a href='https://powerzure.readthedocs.io/en/latest/Functions/operational.html#add-azureadrole'>
            https://powerzure.readthedocs.io/en/latest/Functions/operational.html#add-azureadrole
        </a>
    );
};

export default References;
