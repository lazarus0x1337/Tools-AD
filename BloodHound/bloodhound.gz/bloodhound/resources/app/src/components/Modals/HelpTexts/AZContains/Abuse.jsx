import React from 'react';

const Abuse = () => {
    return (
        <p>
            There is no abuse necessary, but any roles scoped on a parent object
            will descend down to all child objects.
        </p>
    );
};

export default Abuse;
