import React from 'react';

const General = () => {
    return (
        <p>
            The Virtual Machine contributor role grants almost all abusable
            privileges against Virtual Machines.
        </p>
    );
};

export default General;
