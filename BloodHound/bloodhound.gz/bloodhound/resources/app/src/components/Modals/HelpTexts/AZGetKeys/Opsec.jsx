import React from 'react';

const Opsec = () => {
    return (
        <p>
            Azure will create a new log event for the key vault whenever a
            secret is accessed.
        </p>
    );
};

export default Opsec;
