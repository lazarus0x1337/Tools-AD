import React from 'react';

const General = () => {
    return (
        <p>
            The User Access Admin role can edit roles against many other objects
        </p>
    );
};

export default General;
