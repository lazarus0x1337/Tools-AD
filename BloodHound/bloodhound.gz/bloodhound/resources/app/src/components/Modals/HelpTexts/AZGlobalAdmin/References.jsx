import React from 'react';

const References = () => {
    return (
        <a href='https://blog.netspi.com/attacking-azure-cloud-shell/'>
            https://blog.netspi.com/attacking-azure-cloud-shell/
        </a>
    );
};

export default References;
