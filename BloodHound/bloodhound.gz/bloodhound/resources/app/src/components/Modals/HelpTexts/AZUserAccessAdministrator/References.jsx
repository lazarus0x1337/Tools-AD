import React from 'react';

const References = () => {
    return (
        <a href='https://blog.netspi.com/maintaining-azure-persistence-via-automation-accounts/'>
            https://blog.netspi.com/maintaining-azure-persistence-via-automation-accounts/
        </a>
    );
};

export default References;
