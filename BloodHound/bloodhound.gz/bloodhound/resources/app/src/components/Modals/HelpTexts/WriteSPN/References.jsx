import React from 'react';

const References = () => {
    return (
        <>
            <a href='https://github.com/PowerShellMafia/PowerSploit/blob/dev/Recon/PowerView.ps1'>
                https://github.com/PowerShellMafia/PowerSploit/blob/dev/Recon/PowerView.ps1
            </a>
            <br />
            <a href='https://www.harmj0y.net/redteaming/kerberoasting-revisited/'>
                https://www.harmj0y.net/redteaming/kerberoasting-revisited/
            </a>
            <br />
            <a href='https://www.ultimatewindowssecurity.com/securitylog/encyclopedia/event.aspx?eventID=4728'>
                https://www.ultimatewindowssecurity.com/securitylog/encyclopedia/event.aspx?eventID=4728
            </a>
        </>
    );
};

export default References;
