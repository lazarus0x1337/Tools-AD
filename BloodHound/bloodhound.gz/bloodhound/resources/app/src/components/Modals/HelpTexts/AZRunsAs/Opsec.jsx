import React from 'react';

const Opsec = () => {
    return <p>No opsec considerations for this edge.</p>;
};

export default Opsec;
