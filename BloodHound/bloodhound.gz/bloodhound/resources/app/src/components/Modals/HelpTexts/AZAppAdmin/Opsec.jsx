import React from 'react';

const Opsec = () => {
    return (
        <p>
            The Azure portal will create a log even whenever a new credential is
            created for a service principal.
        </p>
    );
};

export default Opsec;
