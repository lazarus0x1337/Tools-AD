import React from 'react';

const General = () => {
    return (
        <p>
            The Website Contributor role grants full control of the target 
            Function App or Web App. Full control of either of those types 
            of resources allows for arbitrary command execution against the 
            target resoruce.
        </p>
    );
};

export default General;
