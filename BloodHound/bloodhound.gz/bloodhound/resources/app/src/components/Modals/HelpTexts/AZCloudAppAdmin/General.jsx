import React from 'react';

const General = () => {
    return (
        <p>
            Principals with the Cloud App Admin role can control tenant-resident
            apps
        </p>
    );
};

export default General;
