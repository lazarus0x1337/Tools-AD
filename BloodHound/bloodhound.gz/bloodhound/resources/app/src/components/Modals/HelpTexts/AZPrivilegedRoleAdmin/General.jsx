import React from 'react';

const General = () => {
    return (
        <p>
            The Privileged Role Admin role can grant any other admin role to
            another principal at the tenant level.
        </p>
    );
};

export default General;
