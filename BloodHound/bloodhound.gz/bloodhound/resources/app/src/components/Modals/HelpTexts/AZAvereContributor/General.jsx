import React from 'react';

const General = () => {
    return (
        <p>
            Any principal granted the Avere Contributor role, scoped to the
            affected VM, can reset the built-in administrator password on the
            VM.
        </p>
    );
};

export default General;
