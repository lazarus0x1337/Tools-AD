import React from 'react';

const Opsec = () => {
    return (
        <p>
            The Azure activity log for the tenant will log who added what
            principal to what group, including the date and time.
        </p>
    );
};

export default Opsec;
