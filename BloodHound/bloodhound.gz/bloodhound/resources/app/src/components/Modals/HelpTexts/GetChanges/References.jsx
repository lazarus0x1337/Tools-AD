import React from 'react';

const References = () => {
    return (
        <>
            <a href='https://adsecurity.org/?p=1729'>
                https://adsecurity.org/?p=1729
            </a>
            <br />
            <a href='https://blog.harmj0y.net/redteaming/mimikatz-and-dcsync-and-extrasids-oh-my/'>
                https://blog.harmj0y.net/redteaming/mimikatz-and-dcsync-and-extrasids-oh-my/
            </a>
            <br />
            <a href='https://www.thehacker.recipes/ad/movement/credentials/dumping/dcsync'>
                https://www.thehacker.recipes/ad/movement/credentials/dumping/dcsync
            </a>
        </>
    );
};

export default References;
