import React from 'react';

const Abuse = () => {
    return (
        <p>
            Everything a Contributor can do, with the addition of assigning
            rights to resources.
        </p>
    );
};

export default Abuse;
