import React from 'react';

const References = () => {
    return (
        <a href='https://dirkjanm.io/azure-ad-privilege-escalation-application-admin/'>
            https://dirkjanm.io/azure-ad-privilege-escalation-application-admin/
        </a>
    );
};

export default References;
