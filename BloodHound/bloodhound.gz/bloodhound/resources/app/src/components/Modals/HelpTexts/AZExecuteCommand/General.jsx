import React from 'react';

const General = () => {
    return (
        <p>
            Principals with the Intune Administrators role are able to
            execute arbitrary PowerShell scripts on devices that are joined
            to the Azure Active Directory tenant.
        </p>
    );
};

export default General;
