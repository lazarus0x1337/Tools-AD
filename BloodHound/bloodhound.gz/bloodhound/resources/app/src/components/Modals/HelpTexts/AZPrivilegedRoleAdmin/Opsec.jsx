import React from 'react';

const Opsec = () => {
    return (
        <p>
            The Azure Activity Log will log who activated an admin role for what
            other principal, including the date and time.
        </p>
    );
};

export default Opsec;
