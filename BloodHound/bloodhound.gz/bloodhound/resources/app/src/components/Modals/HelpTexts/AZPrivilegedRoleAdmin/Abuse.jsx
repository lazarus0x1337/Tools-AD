import React from 'react';

const Abuse = () => {
    return (
        <p>
            Activate the Global Admin role for yourself or for another user
            using PowerZure or PowerShell.
        </p>
    );
};

export default Abuse;
