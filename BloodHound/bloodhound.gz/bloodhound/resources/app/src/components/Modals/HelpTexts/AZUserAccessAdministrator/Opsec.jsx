import React from 'react';

const Opsec = () => {
    return <p>Azure will log any role activation event for any object type.</p>;
};

export default Opsec;
