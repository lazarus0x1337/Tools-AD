import React from 'react';

const Abuse = () => {
    return (
        <p>
            This role can be used to grant yourself or another principal any
            privilege you want against Automation Accounts, VMs, Key Vaults, and
            Resource Groups. Use the Azure portal to add a new, abusable role
            assignment against the target object for yourself.
        </p>
    );
};

export default Abuse;
