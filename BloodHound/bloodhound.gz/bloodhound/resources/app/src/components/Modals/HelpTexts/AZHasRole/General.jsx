import React from 'react';

const General = () => {
    return (
        <p>
            This edge indicates that a principal has been granted a particular
            AzureAD admin role.
        </p>
    );
};

export default General;
