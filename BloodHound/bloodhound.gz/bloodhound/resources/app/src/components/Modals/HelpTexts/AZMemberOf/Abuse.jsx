import React from 'react';

const Abuse = () => {
    return (
        <p>
            No abuse is necessary. This edge simply indicates that a principal
            belongs to a security group.
        </p>
    );
};

export default Abuse;
