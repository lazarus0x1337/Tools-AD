import React from 'react';

const Opsec = () => {
    return (
        <p>
            As mentioned in the abuse info, in order to currently abuse this
            primitive the Rubeus C# assembly needs to be executed on some system
            with the ability to send/receive traffic in the domain. See the
            References for more information.
        </p>
    );
};

export default Opsec;
