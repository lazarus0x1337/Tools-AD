import React from 'react';

const Opsec = () => {
    return <p>No opsec considerations apply to this edge.</p>;
};

export default Opsec;
