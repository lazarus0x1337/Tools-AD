import React from 'react';

const References = () => {
    return <a href='https://www.google.com'>References go here</a>;
};

export default References;
