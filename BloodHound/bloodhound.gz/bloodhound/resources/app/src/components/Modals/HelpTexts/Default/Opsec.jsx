import React from 'react';

const Opsec = () => {
    return <></>;
};

export default Opsec;
