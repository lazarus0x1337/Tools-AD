import React from 'react';

const Opsec = () => {
    return (
        <p>
            For detailed information on detection of dcsync as well as opsec
            considerations, see the adsecurity post in the references tab.
        </p>
    );
};

export default Opsec;
