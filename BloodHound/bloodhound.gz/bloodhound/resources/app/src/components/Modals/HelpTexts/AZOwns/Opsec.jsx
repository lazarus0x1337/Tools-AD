import React from 'react';

const Opsec = () => {
    return (
        <p>
            This depends on which abuse you perform, but in general Azure will
            create a log for each abuse action.
        </p>
    );
};

export default Opsec;
