import React from 'react';

const Abuse = () => {
    return (
        <>
            <p>
                You will abuse this relationship by executing a command 
                against the AKS Managed Cluster the edge is emiting from.
                You can target any managed identity assignment scoped to 
                the Virtual Machine Scale Sets under the target Resource Group.
            </p>
        </>
    );
};

export default Abuse;
