import React from 'react';

const Opsec = () => {

    return (
        <>
            <p>
                Access to registry hives can be monitored and alerted via event ID 4656
                (A handle to an object was requested).
            </p>
        </>
    )
};

export default Opsec;
