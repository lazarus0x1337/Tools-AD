import React from 'react';

const References = () => {
    return (
        <a href='https://blog.netspi.com/running-powershell-scripts-on-azure-vms/'>
            https://blog.netspi.com/running-powershell-scripts-on-azure-vms/
        </a>
    );
};

export default References;
