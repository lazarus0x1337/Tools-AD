import React from 'react';

const Opsec = () => {
    return (
        <p>Reading properties from LDAP is an extremely low risk operation.</p>
    );
};

export default Opsec;
