import React from 'react';

const References = () => {
    return (
        <>
            <a href='https://github.com/PowerShellMafia/PowerSploit/blob/dev/Recon/PowerView.ps1'>
                https://github.com/PowerShellMafia/PowerSploit/blob/dev/Recon/PowerView.ps1
            </a>
            <br />
            <a href='https://www.youtube.com/watch?v=z8thoG7gPd0'>
                https://www.youtube.com/watch?v=z8thoG7gPd0
            </a>
            <br />
            <a href='https://www.youtube.com/watch?v=z8thoG7gPd0'>
                https://www.youtube.com/watch?v=z8thoG7gPd0
            </a>
            <br />
            <a href='https://www.thehacker.recipes/ad/movement/dacl/forcechangepassword'>
                https://www.thehacker.recipes/ad/movement/dacl/forcechangepassword
            </a>
            <br />
            <a href='https://www.thehacker.recipes/ad/movement/dacl/readlapspassword'>
                https://www.thehacker.recipes/ad/movement/dacl/readlapspassword
            </a>
            <br />
            <a href='https://eladshamir.com/2019/01/28/Wagging-the-Dog.html'>
                https://eladshamir.com/2019/01/28/Wagging-the-Dog.html
            </a>
            <br />
            <a href='https://www.thehacker.recipes/ad/movement/credentials/dumping/dcsync'>
                https://www.thehacker.recipes/ad/movement/credentials/dumping/dcsync
            </a>
        </>
    );
};

export default References;
