import React from 'react';

const References = () => {
    return (
        <a href='https://blog.netspi.com/attacking-azure-with-custom-script-extensions/'>
            https://blog.netspi.com/attacking-azure-with-custom-script-extensions/
        </a>
    );
};

export default References;
