import React from 'react';

const Abuse = () => {
    return <p>There is no abuse associated with this edge.</p>;
};

export default Abuse;
