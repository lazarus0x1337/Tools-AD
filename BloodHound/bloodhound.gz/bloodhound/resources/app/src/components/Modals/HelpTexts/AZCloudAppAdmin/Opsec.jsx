import React from 'react';

const Opsec = () => {
    return (
        <p>
            Auzre will create a log event whenever a new secret is created for a
            service principal.
        </p>
    );
};

export default Opsec;
