import React from 'react';

const General = () => {
    return (
        <p>
            The Logic Contributor role grants full control
            of the target Logic App. This includes the ability
            to execute arbitrary commands on the Logic App.
        </p>
    );
};

export default General;
