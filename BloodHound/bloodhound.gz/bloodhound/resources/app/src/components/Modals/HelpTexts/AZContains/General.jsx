import React from 'react';

const General = () => {
    return (
        <p>
            This indicates that the parent object contains the child object,
            such as a resource group containing a virtual machine, or a tenant
            "containing" a subscription.
        </p>
    );
};

export default General;
