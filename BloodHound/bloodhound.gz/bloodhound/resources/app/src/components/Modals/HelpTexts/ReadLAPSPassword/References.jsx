import React from 'react';

const References = () => {
    return (
        <>
            <a href='https://www.specterops.io/assets/resources/an_ace_up_the_sleeve.pdf'>
                https://www.specterops.io/assets/resources/an_ace_up_the_sleeve.pdf
            </a>
            <br />
            <a href='https://adsecurity.org/?p=3164'>
                https://adsecurity.org/?p=3164
            </a>
            <a href='https://www.thehacker.recipes/ad/movement/dacl/readlapspassword'>
                https://www.thehacker.recipes/ad/movement/dacl/readlapspassword
            </a>
        </>
    );
};

export default References;
