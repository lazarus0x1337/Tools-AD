import React from 'react';

const General = () => {
    return (
        <p>
            The ability to change another user's password without knowing their
            current password
        </p>
    );
};

export default General;
