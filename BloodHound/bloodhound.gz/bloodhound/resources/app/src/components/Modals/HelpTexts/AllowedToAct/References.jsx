import React from 'react';

const References = () => {
    return (
        <>
            <a href='https://eladshamir.com/2019/01/28/Wagging-the-Dog.html'>
                https://eladshamir.com/2019/01/28/Wagging-the-Dog.html
            </a>
            <br />
            <a href='https://github.com/GhostPack/Rubeus#s4u'>
                https://github.com/GhostPack/Rubeus#s4u
            </a>
            <br />
            <a href='https://gist.github.com/HarmJ0y/224dbfef83febdaf885a8451e40d52ff'>
                https://gist.github.com/HarmJ0y/224dbfef83febdaf885a8451e40d52ff
            </a>
            <br />
            <a href='https://blog.harmj0y.net/redteaming/another-word-on-delegation/'>
                https://blog.harmj0y.net/redteaming/another-word-on-delegation/
            </a>
            <br />
            <a href='https://github.com/PowerShellMafia/PowerSploit/blob/dev/Recon/PowerView.ps1'>
                https://github.com/PowerShellMafia/PowerSploit/blob/dev/Recon/PowerView.ps1
            </a>
            <br />
            <a href='https://github.com/Kevin-Robertson/Powermad#new-machineaccount'>
                https://github.com/Kevin-Robertson/Powermad#new-machineaccount
            </a>
            <br />
            <a href='https://www.thehacker.recipes/ad/movement/kerberos/delegations/rbcd'>
                https://www.thehacker.recipes/ad/movement/kerberos/delegations/rbcd
            </a>
            <br />
            <a href='https://www.thehacker.recipes/ad/movement/domain-settings/machineaccountquota'>
                https://www.thehacker.recipes/ad/movement/domain-settings/machineaccountquota
            </a>
        </>
    );
};

export default References;
