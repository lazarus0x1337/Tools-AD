import React from 'react';

const General = () => {
    return (
        <p>
            This is an error. Please report this to the BloodHound dev team
            along with instructions to replicate.
        </p>
    );
};

export default General;
