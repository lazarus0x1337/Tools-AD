import React from 'react';

const Abuse = () => {
    return <></>;
};
export default Abuse;
