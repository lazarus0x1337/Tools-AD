import React from 'react';

const References = () => {
    return (
        <>
            <a href='https://adsecurity.org/?tag=ad-delegation'>
                https://adsecurity.org/?tag=ad-delegation
            </a>
            <br />
            <a href='https://www.itprotoday.com/management-mobility/view-or-remove-active-directory-delegated-permissions '>
                https://www.itprotoday.com/management-mobility/view-or-remove-active-directory-delegated-permissions{' '}
            </a>
        </>
    );
};

export default References;
