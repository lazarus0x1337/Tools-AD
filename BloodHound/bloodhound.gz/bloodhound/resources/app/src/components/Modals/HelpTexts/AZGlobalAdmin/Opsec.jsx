import React from 'react';

const Opsec = () => {
    return (
        <p>
            This depends on exactly what you do, but in general Azure will log
            each abuse action.
        </p>
    );
};

export default Opsec;
