import React from 'react';

const General = () => {
    return (
        <p>The ability to add other principals to an Azure security group</p>
    );
};

export default General;
