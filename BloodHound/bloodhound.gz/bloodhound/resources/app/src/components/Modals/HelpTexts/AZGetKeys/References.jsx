import React from 'react';

const References = () => {
    return (
        <>
            <a href='https://blog.netspi.com/azure-automation-accounts-key-stores/'>
                https://blog.netspi.com/azure-automation-accounts-key-stores/
            </a>
            <br />
            <a href='https://powerzure.readthedocs.io/en/latest/Functions/operational.html#export-azurekeyvaultcontent'>
                https://powerzure.readthedocs.io/en/latest/Functions/operational.html#export-azurekeyvaultcontent
            </a>
        </>
    );
};

export default References;
