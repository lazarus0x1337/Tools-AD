import React from 'react';

const Opsec = () => {

    return (
        <>
            <p>
                Executing the attack will generate a 4662 (An operation was performed on an object) event at the domain controller if an appropriate SACL is in place on the target object.
            </p>
        </>
    )
};

export default Opsec;
